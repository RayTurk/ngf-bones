<?php
global $theme_vars;
    $theme_vars = array (
        'header_logo' => get_template_directory_uri().'/img/logo.png',
        'footer_logo' => get_template_directory_uri().'/img/logo.png',
        'Street Address' => '6192 Spring Valley Dr',
        'City' => 'Holland',
        'State' => 'OH',
        'Zip' => '43528',
        'phone' => '419-842-4462',
    );
?>