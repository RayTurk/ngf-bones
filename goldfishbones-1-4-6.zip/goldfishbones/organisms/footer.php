<?php 
//Design Library Name: Footer
//Description: This is the prototype implimentation of the page Footer. It is very basic
?>	
        <footer id="footer" role="contentinfo">
            <div class="container">

            </div>
        </footer>
		