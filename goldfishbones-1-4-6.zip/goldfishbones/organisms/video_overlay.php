<style>
    .video_overlay {
        position: absolute;
        top: 0;
        width: 100%;
    }
</style>
<div class="video_overlay">
    <div class="container">
        <?php echo $vars['overlay'];?>
    </div>
</div>