<div class="block-feature">
    <h3><?php echo $vars['BlockTitle'];?></h3>
    <div class="img"><img class="featured-img" src="<?php echo $vars['BlockImage'];?>" alt="<?php echo $vars['BlockImageAlt'];?>"></div>
    <div class="content">
        <?php echo $vars['BlockContent'];?>
        <a class="btn" title="<?php echo $vars['ButtonText'];?>" href="<?php echo $vars['FeatureLink'];?>"><?php echo $vars['ButtonText'];?></a>
    </div>
    
</div>