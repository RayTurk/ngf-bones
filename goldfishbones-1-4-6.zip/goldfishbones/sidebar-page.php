<?php if (is_active_sidebar('sidebar-page')) { ?> 
					<?php do_action('before_sidebar'); ?> 
					<?php dynamic_sidebar('sidebar-page'); ?> 
<?php } ?> 