<?php
/**
 * The theme footer
 * 
 * @package bootstrap-basic
 */
global $theme_vars;
?>

			
			
			
        <footer id="footer" role="contentinfo">
            <div class="container">

            </div>
        </footer>
        