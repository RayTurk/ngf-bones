<?php 
// footer Logo, draws from theme variables the logo image"
global $theme_vars;
?>
<img src="<?php echo $theme_vars['footer_logo'];?>" alt="logo" class="logo">