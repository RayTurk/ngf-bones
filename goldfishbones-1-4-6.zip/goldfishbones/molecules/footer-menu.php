<?php
  wp_nav_menu( array(
    'menu'		=> 'Footer Menu',
    'container'         => false,

  ));?>