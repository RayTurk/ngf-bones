<div class="video_container">
    <?php echo $vars['embed'];?>
</div>