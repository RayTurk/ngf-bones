<?php global $theme_vars;?>
<a title="Return to Home" href="/"><img src="<?php echo $theme_vars['header_logo'];?>" alt="Logo"></a>