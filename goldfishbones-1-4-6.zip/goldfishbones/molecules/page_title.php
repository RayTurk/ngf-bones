<div class="row row-title">
    <div class="col-sm-12 col">
        <h1><?php echo $vars['pageTitle'];?></h1>
    </div>
</div>