<div class="col-md-12 carousel-post">
<div class="content"><?php the_content();?></div>
<h3><?php the_title();?></h3>
</div>