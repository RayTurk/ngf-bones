<?php
global $theme_vars;
?>
<div class="text_cta"><?php echo $theme_vars['Header CTA'];?></div>