<div id="default_content">
    <div class="container main-content">
        <?php get_atomic_part ('molecules/page_title.php', $args);?>
        <div class="row content-row justify-content-center">

            <div class="col-md-8 main">
                <?php echo apply_filters( 'the_content', $args['content']); ?>
            </div>

        </div>
    </div>
</div>