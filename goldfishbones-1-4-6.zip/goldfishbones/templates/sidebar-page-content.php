<div id="default_content_sidebar">
    <div class="container main-content">
        <?php get_atomic_part ('molecules/page_title.php', $args);?>
        <div class="row">
            <div class="col-sm-12 col-md-8 main">
                <?php echo apply_filters( 'the_content', $args['content']); ?>
            </div>
            <div class="col-md-4 sidebar">
                <?php get_sidebar('page');?>
            </div>
        </div>
    </div>
</div>