 <div id="<?php echo get_sub_field('css_id');?>" class="page_section post_carousel"> 
    <div class="container">
        <div class="post_slider">
        <?php
            if (get_sub_field('title') != "") {
                echo '<h2>'.get_sub_field('title').'</h2>';
            }
            echo $number.' '.$type;
            // WP_Query arguments
                $args = array(
                    'posts_per_page'         => $number,
                    'post_type'              => $type,
                );

                // The Query
                $queryHome = new WP_Query( $args );

                // The Loop
                if ( $queryHome->have_posts() ) {
                    echo '<div class="row">';
                    while ( $queryHome->have_posts() ) {
                        $queryHome->the_post();
                        get_template_part('/molecules/carousel_post',$type);
                    }
                    echo '</div>';
                } else {
                    get_atomic_part('/molecules/posts_not_found.php',none);
                }

                // Restore original Post Data
                wp_reset_postdata();    
                        
        ?>
        </div>
        
    </div>
</div>